def add_numbers(a, b):
    return a + b

print(add_numbers(3, 4))
print(add_numbers(18, 4))