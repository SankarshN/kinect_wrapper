class MaskingClass:
    def get_mask(self):
        pass